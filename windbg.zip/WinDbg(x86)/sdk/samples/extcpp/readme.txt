                   Microsoft(R) Debugging Tools for Windows(R)
                      ExtCpp.dll EngExtCpp Sample Extension
                                      README


Overview

This extension DLL shows how to write an extension using the EngExtCpp
C++ extension framework and demonstrates use of a few APIs provided by
the framework.

----------
Extensions Implemented in this Sample


ummods

This demonstrates use of ExtCpp methods that handle typed data
and typed lists.
